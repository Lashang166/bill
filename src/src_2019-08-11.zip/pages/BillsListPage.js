/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useEffect, useState } from "react";
import { Link, Redirect } from "react-router-dom";
import Helmet from "react-helmet";
import axios from "axios";
import isLoggedIn from "./../helpers/is_logged_in";
import store from "store";
import formatMoney from "../lib/FormatMoney";
import isEmptyObject from "../lib/IsEmptyObject";
import ModalImage from "../components/ModalImage";

// const apiServer = "http://localhost:8080"; // "."

//const apiServer = ".";
const apiServer = "http://bill.i-sabuy.xyz/Bill";

export default function BillsListPage(props) {
  const [billsList, setBillsList] = useState([]);
  const [islogin, setIslogin] = useState(0);
  const [modalshow, setmodalshow] = useState(false);
  const [modalImage, setmodalImage] = useState("");

  useEffect(() => {
    axios.get(`${apiServer}/ci-api/bills/listAllBills`).then(result => {
      console.log(result.data);
      setBillsList(result.data);
    });
  }, []);

  if (!isLoggedIn()) {
    return <Redirect to="/login" />;
  }

  const handleLogout = evt => {
    evt.preventDefault();
    store.remove("user");
    setIslogin(islogin + 1);
  };

  const viewSlip = input => {
    //evt.preventDefault();
    //console.log(e);
    setmodalImage(input);
    setmodalshow(true);
  };

  const checklogin = () => {
    if (islogin > 0) {
      return <Redirect to="/login" />;
    }
  };

  // console.log(billsList);
  return (
    <div className="container">
      <Helmet title="I-Sabuy Bill List for test" />
      <div className="columns">
        <div className="column">
          <div className="field is-grouped is-pulled-right	">
            <div className="control">
              {" "}
              <button className="button is-success">
                <i className="fa fa-plus" /> &nbsp; เปิดบิล
              </button>
            </div>
            <div className="control">
              <div className="field has-addons has-addons-right">
                <div className="control">
                  <span className="select">
                    <select>
                      <option>ชื่อลูกค้า</option>
                      <option>เลขที่บอล</option>
                      <option>วันที่</option>
                    </select>
                  </span>
                </div>
                <div className="control">
                  <input className="input" type="text" placeholder="ค้นหา" />
                </div>
                <div className="control">
                  <a className="button is-info">ค้นหา</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="columns is-multiline">
        {billsList.map((bill, idx) => {
          const data = JSON.parse(bill.Data);

          //summary
          let total = data.items.reduce((totalValue, item) => {
            // console.log(item.Amount, item.PricePerUnit);
            return (
              totalValue +
              parseFloat(item.Amount) * parseFloat(item.PricePerUnit)
            );
          }, 0);
          let postalCharge = data.ShipTypes.reduce(
            (Value, ShipType) =>
              Value +
              (ShipType.id === data.SelectedShipType
                ? parseFloat(ShipType.rate)
                : 0),
            0
          );
          const DiscountValue =
            bill.DiscountType === "VALUE"
              ? bill.DiscountValue
              : total * (parseFloat(bill.DiscountValue) / 100);

          //console.log(data);
          let customerName = "-";
          let billStatus = "-";
          let imageSlip;

          if (data.ShippingAddress) {
            if (data.ShippingAddress.Name) {
              customerName = data.ShippingAddress.Name;
            }
          }

          if (!isEmptyObject(data.Payment)) {
            if (data.Payment.BankAccount.type == "COD") {
              imageSlip = (
                <img
                  src="/assets/cod.png"
                  alt="cod"
                  onClick={e => {
                    //setmodalshow(true);
                    //viewSlip(true);
                    const imgPath = "/assets/cod.png";
                    viewSlip(imgPath);

                    //setImageSlip(`${apiServer}/ci-api/${data.Payment.image}`);
                    //setModal(true);
                  }}
                />
              );
            } else {
              if (!isEmptyObject(data.Payment.image)) {
                imageSlip = (
                  <img
                    src={`${apiServer}/ci-api/${data.Payment.image}`}
                    alt={data.Payment.image}
                    onClick={e => {
                      //setmodalshow(true);
                      //viewSlip(true);
                      const imgPath = `${apiServer}/ci-api/${
                        data.Payment.image
                      }`;
                      viewSlip(imgPath);

                      //setImageSlip(`${apiServer}/ci-api/${data.Payment.image}`);
                      //setModal(true);
                    }}
                  />
                );
              }
            }
          }

          switch (bill.BillStatus.toString()) {
            case "0.0": {
              billStatus = "DRAFT";
              break;
            }
            case "1.0": {
              billStatus = "NEW";
              break;
            }
            case "1.1": {
              billStatus = "ERROR_PAYMENT";
              break;
            }
            case "2.0": {
              billStatus = "WAIT_FOR_ADDRESS";
              break;
            }
            case "2.1": {
              billStatus = "ERROR_ADDRESS";
              break;
            }
            case "3.0": {
              billStatus = "CHECK_PAYMENT";
              break;
            }
            case "4.0": {
              billStatus = "PREPARE_ITEMS";
              break;
            }
            case "5.0": {
              billStatus = "ITEMS_SENT";
              break;
            }
            default: {
              billStatus = "-";
              break;
            }
          }

          /*
          const customerName = data.ShippingAddress.Name
            ? data.ShippingAddress.Name
            : "-";*/
          return (
            <div key={idx} className="column is-one-third">
              <div className="card">
                <div className="card-content">
                  <div className="media">
                    <div className="media-left">
                      <figure className="image is-48x48">
                        <img src={bill.VLogo} alt={bill.VName} />
                      </figure>
                    </div>
                    <div className="media-content">
                      <p className="title is-4">Bill# {bill.BillNo}</p>
                      {/* <p className="subtitle is-6">{bill.VName}</p> */}
                    </div>
                  </div>

                  <div className="media">
                    <div className="media-content">
                      <div>สถานะ: {billStatus}</div>
                      <div>ลูกค้า: {customerName}</div>
                      <div>
                        จำนวนเงินทีเปิดบิล:{" "}
                        {formatMoney(total + postalCharge - DiscountValue)}
                      </div>
                    </div>
                    <div className="media-right">
                      <figure className="image is-128x128">{imageSlip}</figure>
                    </div>
                  </div>
                </div>
                <footer className="card-footer">
                  <Link
                    to={`/bill/${bill.BillNo}`}
                    className="card-footer-item"
                  >
                    เปลี่ยนสถานะ
                  </Link>
                  <Link
                    to={`/billedit/${bill.BillNo}`}
                    className="card-footer-item"
                  >
                    แก้ไข
                  </Link>
                </footer>
              </div>
            </div>
          );
        })}
        <button
          className="button is-block is-danger is-large is-fullwidth"
          onClick={handleLogout}
        >
          Logout
        </button>
      </div>

      <div className="columns">
        <div className="column">
          <nav
            className="pagination is-right"
            role="navigation"
            aria-label="pagination"
          >
            <a className="pagination-previous">Previous</a>
            <a className="pagination-next">Next page</a>
            <ul className="pagination-list">
              <li>
                <a className="pagination-link" aria-label="Goto page 1">
                  1
                </a>
              </li>
              <li>
                <span className="pagination-ellipsis">&hellip;</span>
              </li>
              <li>
                <a className="pagination-link" aria-label="Goto page 45">
                  45
                </a>
              </li>
              <li>
                <a
                  className="pagination-link is-current"
                  aria-label="Page 46"
                  aria-current="page"
                >
                  46
                </a>
              </li>
              <li>
                <a className="pagination-link" aria-label="Goto page 47">
                  47
                </a>
              </li>
              <li>
                <span className="pagination-ellipsis">&hellip;</span>
              </li>
              <li>
                <a className="pagination-link" aria-label="Goto page 86">
                  86
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
      <div>
        <ModalImage
          showHide={modalshow}
          modalImg={modalImage}
          setmodal={input => {
            setmodalshow(input);
          }}
        />
      </div>
    </div>
  );
}
