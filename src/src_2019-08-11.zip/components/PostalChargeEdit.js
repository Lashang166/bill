import React, { useState } from "react";
import formatMoney from "../lib/FormatMoney";
export default function PostalCharge({
  ShipTypes,
  SelectedShipType,
  UpdateState,
  setBillShipType,
  updateShipTypes
}) {
  const [shiptypes, setshiptypes] = useState(ShipTypes);
  SelectedShipType = SelectedShipType ? SelectedShipType : ShipTypes[0].id;

  const editItem = (id, inputz) => {
    const newShip = shiptypes.map((s, _idx) => {
      if (s.id !== id) return s;
      // this is gonna create a new object, that has the fields from
      // `s`, and `name` set to `newName`
      //const newInput = !isNaN(inputz) ? parseFloat(inputz) : inputz;
      //return { ...s, rate: newInput };
      return { ...s, rate: inputz };
    });

    setshiptypes(newShip);
    updateShipTypes(newShip);
    //setBillShipType(shiptypes);
  };

  const changeExpress = input => {
    UpdateState(input);
    setBillShipType(input);
  };

  const focusItem = e => {
    e.currentTarget.select();
  };

  return (
    <div className="my-padding">
      เลือกวิธีจัดส่งสินค้า
      {shiptypes.map((ShipType, idx) => {
        return (
          <div
            key={idx}
            style={{ cursor: "pointer", marginTop: "10px" }}
            onClick={e => {
              changeExpress(ShipType.id);
            }}
          >
            <i
              className={`my-padding-right far ${
                ShipType.id === SelectedShipType
                  ? "fa-check-square has-text-success"
                  : "fa-check-square has-text-grey-light"
              }`}
            />
            {ShipType.description}
            <span className="is-pulled-right">
              <input
                className="input is-small"
                value={ShipType.rate}
                onChange={e => {
                  editItem(ShipType.id, e.target.value);
                }}
                onFocus={e => {
                  focusItem(e);
                }}
                style={{ width: "80px" }}
              />{" "}
              บาท
            </span>
          </div>
        );
      })}
      {/* <select
        className="is-pulled-right"
        value={SelectedShipType}
        onChange={e => {
          UpdateState(e.target.value);
        }}
      >
        {ShipTypes.map((ShipType, idx) => {
          // console.log(ShipType);
          return (
            <option key={idx} value={ShipType.id}>
              {ShipType.description}
            </option>
          );
        })}
        }
      </select> */}
    </div>
  );
}
