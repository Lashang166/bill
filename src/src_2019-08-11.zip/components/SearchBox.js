import React, { useState } from "react";

export default function SearchBox({
  label,
  name,
  value,
  placeholder,
  type,
  onInputChange,
  searchFunction,
  FormatResult,
  className
}) {
  const [searchResult, setSearchResult] = useState([]);
  const [isFocus, setIsFocus] = useState(false);
  let thisTime = new Date().getTime();

  return (
    <div className="field">
      <label className="label">{label}</label>
      <div className="control">
        <input
          onFocus={() => {
            setIsFocus(true);
          }}
          onBlur={() => {
            setTimeout(() => {
              setIsFocus(false);
            }, 250);
          }}
          className={`input ${className}`}
          id={`searchbox-${name}`}
          value={value}
          type={type}
          onChange={e => {
            onInputChange(e);
            // setSearchResult(searchFunction(e.target.value, 4));
            setSearchResult(searchFunction(e.target.value, 15));
          }}
          placeholder={placeholder}
        />
        <div
          id={`searchboxresult-${name}`}
          className={`${isFocus ? "" : "is-hidden"}`}
          style={{zIndex:999}}
        >
          {searchResult.map((s, idx) => {
            thisTime++;
            return (
              <div className="content" key={thisTime}>
                {FormatResult(s)}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
