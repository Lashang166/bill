/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState, useEffect } from "react";
import formatMoney from "../lib/FormatMoney";
import axios from "axios";
import store from "store";
import { NONAME } from "dns";

const apiServer = "https://www.i-sabuy.com";

export default function BillItems({ items, setBillItems }) {
  const [billitems, setbillitem] = useState(items);
  const [editBill, setEditBill] = useState(false);
  const [token, setToken] = useState("");
  const [searchdata, setSearchData] = useState("");
  const [searchitems, setSearchItems] = useState([]);
  const [choosesku, setChoosesku] = useState("");

  console.log("items = ", items);
  console.log("searchItems = ", searchitems);

  useEffect(() => {
    const userInfo = store.get("user");
    setToken(userInfo.amtk);
    console.log("user = " + userInfo.amtk);
  }, []);

  useEffect(() => {
    if (searchdata.length >= 1) {
      axios
        .get(
          `http://i-sabuy.xyz/warehouse/ajax/product.php?token=${token}&keyword=${searchdata}`
        )
        .then(result => {
          console.log(result);
          setSearchItems(result.data.data);
        })
        .catch(e => {
          console.log("Error updating", e);
        });
    }
  }, [searchdata]);

  const changePrice = (i, event) => {
    console.log("change = " + event.target.value);

    //if (!isNaN(event.target.value) && event.target.value) {
    //const newValue = event.target.value;

    let newValue = billitems.map((item, _idx) => {
      if (_idx !== i) return item;

      return {
        ...item,
        PricePerUnit: event.target.value
      };
    });

    setbillitem(newValue);
    setBillItems(newValue);
    //}
  };

  const changeQty = (i, event) => {
    console.log("change = " + event.target.value);

    //if (!isNaN(event.target.value) && event.target.value) {
    //const newValue = event.target.value;

    let newValue = billitems.map((item, _idx) => {
      if (_idx !== i) return item;

      return {
        ...item,
        Amount: event.target.value
      };
    });

    setbillitem(newValue);
    setBillItems(newValue);
    //}
  };

  const oneClick = item => {
    //console.log("doubleClick = " , item);
    if (item.SKU === choosesku) {
      let newItem = {
        Amount: 1,
        Description: item.Title,
        PricePerUnit: item.PricePerUnit,
        SKU: item.SKU,
        UnitName: "",
        total: item.PricePerUnit,
        image: `${apiServer}${item.ProductImageUrl.thumb}`
      };
      setbillitem([...billitems, newItem]);
      setBillItems([...billitems, newItem]);

      setEditBill(false);
    } else {
      setChoosesku(item.SKU);
    }
  };

  const deleteItem = (inputItem, idx) => {
    const newValue = billitems.filter((item, idx) => {
      if (item.SKU !== inputItem.SKU) {
        return item;
      }
    });
    setbillitem(newValue);
    setBillItems(newValue);
  };

  const focusItem = e => {
    e.currentTarget.select();
  };

  return (
    <div className="my-padding">
      <div>
        <strong> รายการสินค้า </strong>{" "}
      </div>{" "}
      {billitems.map((item, idx) => {
        return (
          <div key={idx} className="columns is-mobile">
            {" "}
            <div className="column is-one-quarter">
              <div className="image is-64x64">
                <button
                  className="delete is-small"
                  onClick={() => {
                    deleteItem(item, idx);
                  }}
                  style={{ position: "absolute" }}
                />
                <img src={item.image} alt="item.SKU" />
              </div>

              {/*}
              <div className="card" style={{ boxShadow: "none" }}>
                <div className="image is-64x64">
                  <img src={item.image} alt={item.SKU} />
                </div>
                <div className="is-overlay">
                  <span
                    className="tag is-small"
                    style={{
                      cursor: "pointer",
                      backgroundColor: "transparent"
                    }}
                    onClick={() => {
                      deleteItem(item, idx);
                    }}
                  >
                    <i className="fas fa-trash-alt"> </i>
                  </span>
                </div>
              </div>
              {*/}
            </div>
            {/* ProductName */}
            <div className="column">
              <div>
                {" "}
                {item.Description} <br />[{item.SKU}]
              </div>
            </div>
            <div className="column is-one-third has-text-right">
              <p className="control has-icons-left ">
                <input
                  className="input is-small is-pulled-right has-text-right"
                  value={item.PricePerUnit}
                  onChange={e => {
                    changePrice(idx, e);
                  }}
                  onFocus={e => {
                    focusItem(e);
                  }}
                />
                <span className="icon is-small is-left">
                  <i className="fas fa-tags" />
                </span>
              </p>
              <p className="control has-icons-left">
                <input
                  className="input is-small is-pulled-right has-text-right"
                  value={item.Amount}
                  onChange={e => {
                    changeQty(idx, e);
                  }}
                  onFocus={e => {
                    focusItem(e);
                  }}
                  style={{ marginTop: "3px" }}
                />
                <span className="icon is-small is-left">
                  <i className="fas fa-sort-numeric-down" />
                </span>
              </p>
              <span className="is-pulled-right">
                {formatMoney(
                  parseFloat(item.Amount) * parseFloat(item.PricePerUnit)
                )}
                บาท{" "}
              </span>
            </div>
          </div>
        );
      })}
      {!editBill ? (
        <a
          className="button is-success is-rounded is-small-mobile is-fullwidth"
          onClick={() => setEditBill(true)}
          style={{ marginTop: "10px" }}
        >
          <i className="fas fa-plus"> </i> &nbsp; เพิ่มสินค้า
        </a>
      ) : (
        <a
          className="button is-warning is-rounded is-small-mobile is-fullwidth"
          onClick={() => setEditBill(false)}
          style={{ marginTop: "10px" }}
        >
          <i className="fas fa-times"> </i> &nbsp; ยกเลิก
        </a>
      )}{" "}
      {editBill ? (
        <div>
          <br />
          <input
            className="input"
            value={searchdata}
            onChange={e => {
              setSearchData(e.target.value);
            }}
            placeholder="ค้นหา"
          />{" "}
        </div>
      ) : null}
      <br />
      {editBill ? (
        <div className="columns is-multiline is-mobile is-gapless">
          {" "}
          {searchitems.map((searchitem, idx) => {
            let imgUrl = `${apiServer}${searchitem.ProductImageUrl.thumb}`;
            return (
              <div
                key={idx}
                className={
                  searchitem.SKU === choosesku
                    ? "column is-one-quarter has-text-centered has-background-primary"
                    : "column is-one-quarter has-text-centered"
                }
                onClick={() => {
                  oneClick(searchitem);
                }}
              >
                <div
                  className="image container is-64x64"
                  style={{ marginTop: "5px" }}
                >
                  {" "}
                  <img src={imgUrl} alt="" />{" "}
                </div>{" "}
                <p className="is-size-7	has-text-centered"> {searchitem.SKU} </p>
              </div>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}
