import React from "react";

export default function BillVendor({
  VendorName,
  VendorLogo,
  VendorAddress,
  AgentMobile
}) {
  return (
    <div className="my-padding">
      <figure className="is-pulled-left is-inline">
        <p className="image is-64x64" style={{ paddingRight: "1rem" }}>
          <img src={VendorLogo ? VendorLogo : ""} alt="" />
        </p>
      </figure>
      <span>
        <div className="container">
          <p>
            <strong>{VendorName ? VendorName : ""}</strong>
            <br />
            {VendorAddress ? VendorAddress : ""} |{" "}
            {AgentMobile ? AgentMobile : ""}
          </p>
        </div>
      </span>
    </div>
  );
}
