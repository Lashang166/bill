import React, { useState, useEffect } from "react";
import formatMoney from "../lib/FormatMoney";

export default function BillTotal({
  TotalValue,
  PostalCharge,
  PostalName,
  Discount,
  DiscountType,
  setBillDiscount,
  setDiscountType
}) {
  const [discount, setdiscount] = useState(Discount);
  const [discounttype, setdiscounttype] = useState(DiscountType);
  const [discountvalue, setdiscountvalue] = useState(0);
  const [discountpercent, setdiscountpercent] = useState(0);

  useEffect(() => {
    if (discounttype === "VALUE") {
      setdiscount(discount);
      setdiscountvalue(discount);
      //setdiscountpercent(0);
    } else {
      //Percent
      const newValue = TotalValue * (parseFloat(discount) / 100);
      setdiscount(newValue);
      setdiscountvalue(discount);
      //setdiscountpercent(0);
    }
  }, []);

  const changeDiscountPercent = event => {
    setdiscountpercent(event.target.value);
    const newValue = TotalValue * (parseFloat(event.target.value) / 100);
    setdiscount(newValue);
    setBillDiscount(newValue);

    //clear
    setdiscounttype("PERCENTAGE");
    setDiscountType("PERCENTAGE");
    setdiscountvalue(0);
  };

  const changeDiscountValue = event => {
    setdiscountvalue(event.target.value); //set input

    if (discounttype === "PERCENTAGE") {
      const newValue = TotalValue * (parseFloat(event.target.value) / 100);
      setdiscount(newValue);
    } else {
      setdiscount(event.target.value);
    }

    //Update bill to API
    setBillDiscount(event.target.value);
    setDiscountType(discounttype);
  };

  const changeDiscountType = event => {
    const input = event.currentTarget.value;

    if (input === "PERCENTAGE") {
      const newValue = TotalValue * (parseFloat(discountvalue) / 100);
      setdiscount(newValue);
    } else {
      setdiscount(discountvalue);
    }

    setdiscounttype(input); //state

    //Update bill to API
    setDiscountType(input);
    setBillDiscount(discountvalue);
  };

  const focusItem = e => {
    e.currentTarget.select();
  };

  /*
  const DiscountValue =
    DiscountType === "VALUE"
      ? discount
      : TotalValue * (parseFloat(discount) / 100)
  */

  //const DiscountText = DiscountType === "VALUE" ? "(บาท)" : "(%)";

  return (
    <div className="my-padding">
      <div>
        ค่าสินค้า
        <span className="is-pulled-right">{formatMoney(TotalValue)} บาท</span>
      </div>
      {/*}
      {parseFloat(Discount) > 0 ? (
        <div>
          ส่วนลด
          <span className="is-pulled-right">
            {formatMoney(DiscountValue)} บาท
          </span>
        </div>
      ) : null}
      {*/}
      {/*
      <div className="box-padding">
        ส่วนลด
        <span className="is-pulled-right">
          <input
            className="input is-small"
            value={discount}
            onChange={e => {
              changeDiscount(e);
            }}
            onFocus={e => {
              focusItem(e);
            }}
          />
        </span>{" "}
        {DiscountText}
      </div>
      {*/}
      <div className="field is-horizontal">
        <div className="field-body container">
          <div className="field">
            <span>ส่วนลด</span>{" "}
            <div className="select is-small" style={{ marginLeft: "5px" }}>
              <select
                value={discounttype}
                onChange={e => {
                  changeDiscountType(e);
                }}
              >
                <option value="PERCENTAGE">%</option>
                <option value="VALUE">บาท</option>
              </select>
            </div>{" "}
            <input
              className="input is-success is-small"
              type="text"
              placeholder="ป้อนส่วนลด"
              style={{ width: "70px", marginLeft: "5px" }}
              value={discountvalue}
              onChange={e => {
                changeDiscountValue(e);
              }}
              onFocus={e => {
                focusItem(e);
              }}
            />
            <span className="is-pulled-right has-text-danger">
              - {formatMoney(discount)} บาท
            </span>
          </div>
        </div>
      </div>
      <div>
        ค่าส่งสินค้า {PostalName}
        <span className="is-pulled-right">{formatMoney(PostalCharge)} บาท</span>
      </div>
      <div>
        <strong className="is-size-5">รวมเป็นเงิน</strong>
        <strong className="is-pulled-right is-size-5 has-text-success">
          {formatMoney(TotalValue + PostalCharge - discount)} บาท
        </strong>
      </div>
    </div>
  );
}
