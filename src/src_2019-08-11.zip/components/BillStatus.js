import React from "react";
import pageConfig from "../config.json";

export default function BillStatus({ status, statustext, link }) {
  console.log("BillStatus", status, pageConfig.billStatus);
  if (!pageConfig.billStatus[status.toString()]) {
    return null;
  }
  const thisConfig = pageConfig.billStatus[status];
  return (
    <div className="my-padding-bottom my-margin-top has-background-white">
      <div className="my-padding has-round-border">
        <div>
          สถานะ:
          <span
            className="is-pulled-right"
            style={{ color: thisConfig.backgroundColor }}
          >
            {thisConfig.text}
          </span>
        </div>
        <div
          className="my-padding"
          style={{
            backgroundColor: thisConfig.backgroundColor,
            color: thisConfig.textColor
          }}
        >
          {`${thisConfig.description} ${
            [1.1, 2.1].includes(parseFloat(status)) ? statustext : ""
          }`}
          {parseFloat(status) > 4 ? (
            <>
              <a href={link}>สถานะพัสดุ</a>
            </>
          ) : (
            ""
          )}
        </div>
      </div>
    </div>
  );
}
