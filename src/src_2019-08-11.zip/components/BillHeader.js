import React, { useState } from "react";
import moment from "moment";
export default function BillHeader({
  BillNumber,
  BillDate,
  BillDueDate,
  ShippingAddress,
  BillNote,
  setBillNote
}) {
  const [editMode, setEditMode] = useState(false);
  const [billnote, setbillnote] = useState(BillNote);
  return (
    <div className="my-padding">
      <div>
        <strong>เลขที่บิล {BillNumber}</strong>
      </div>
      {ShippingAddress && ShippingAddress.Name ? (
        <div>
          ชื่อลูกค้า
          <span className="is-pulled-right">
            <strong>{ShippingAddress.Name}</strong>
          </span>
        </div>
      ) : null}
      <div>
        วันที่เปิดบิล
        <span className="is-pulled-right">{moment(BillDate).format("LL")}</span>
      </div>
      <div>
        วันที่ครบกำหนด
        <span className="is-pulled-right">
          {moment(BillDueDate).format("LL")}
        </span>
      </div>
      <div>
        {editMode ? (
          <>
            <div className="field is-horizontal">
              <div
                className="field-label is-normal has-text-left"
                style={{ flexGrow: 2 }}
              >
                <label className="label" style={{ fontWeight: 300 }}>
                  ข้อความถึงผู้ขาย
                </label>
              </div>
              <div className="field-body">
                <div className="field has-addons">
                  <div className="control" style={{ flexGrow: 2 }}>
                    <input
                      className="input"
                      type="text"
                      placeholder=""
                      value={billnote}
                      onChange={e => {
                        setbillnote(e.target.value);
                      }}
                    />
                  </div>
                  <div className="control">
                    <button
                      className="button is-info"
                      onClick={e => {
                        setEditMode(false);
                        setBillNote(billnote);
                      }}
                    >
                      บันทึก
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <>
            ข้อความถึงผู้ขาย {BillNote}
            <a
              href="#t"
              onClick={e => {
                e.preventDefault();
                setEditMode(true);
              }}
            >
              <i className="far fa-edit is-primary" style={{marginLeft:'6px'}} />
              {BillNote && BillNote !== "" ? "แก้ไข" : "เพิ่มโน๊ต"}
            </a>
          </>
        )}
      </div>
    </div>
  );
}
