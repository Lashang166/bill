import React from "react";

export default function BillActionProcessing({ BillNo }) {
  return (
    <div>
      {/* <figure
        className="has-text-centered"
        // style={{
        //   position: "absolute",
        //   top: "50%",
        //   left: "50%",
        //   transform: "translate(-50%, -50%)"
        // }}
      >
        <div className="image">
          <center>
            <img
              src="./assets/in-delivery.jpg"
              style={{
                maxWidth: "240px",
                maxHeight: "240px",
                width: "auto",
                height: "auto"
              }}
              alt={`กำลังจัดส่งเลขที่บิล ${BillNo}`}
            />
          </center>
        </div>
      </figure> */}
    </div>
  );
}
