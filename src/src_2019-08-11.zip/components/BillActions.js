import React from "react";

import BillActionPayment from "./BillActionPayment";
import BillActionPostalAddress from "./BillActionPostalAddress";
// import BillActionProcessing from "./BillActionProcessing";
// import BillActionOrderSent from "./BillActionOrderSent";

function renderStep(
  BillNo,
  step,
  BankAccounts,
  Payment,
  ShippingAddress,
  setPayment,
  setBillStatus,
  setShippingAddress
) {
  console.log("BillActions:Payment", Payment);
  switch (parseInt(step, 10)) {
    case 1:
      return (
        <BillActionPayment
          BillNo={BillNo}
          BankAccounts={BankAccounts}
          Payment={Payment}
          setBillStatus={status => {
            if (parseInt(status, 10) === 1) {
              setPayment("");
            }
            setBillStatus(status);
          }}
          SetPaymentData={fileUrl => {
            setPayment(fileUrl);
          }}
        />
      );

    case 2:
      return (
        <BillActionPostalAddress
          ShippingAddress={ShippingAddress}
          updateShippingAddress={setShippingAddress}
          setBillStatus={setBillStatus}
        />
      );
    // case 3:
    // return <BillActionProcessing BillNo={BillNo} />;
    // case 4:
    // return (
    //   <BillActionOrderSent
    //     BillNo={BillNo}
    //     tracking={ShippingAddress.Tracking}
    //   />
    // );
    // case 5:
    //   return null;
    default:
      return null;
  }
}

export default function BillActions({
  BillNo,
  BankAccounts,
  ShippingAddress,
  Payment,
  setBillStatus,
  Step,
  setPayment,
  setShippingAddress
}) {
  return (
    <div>
      {renderStep(
        BillNo,
        Step,
        BankAccounts,
        Payment,
        ShippingAddress,
        setPayment,
        setBillStatus,
        setShippingAddress
      )}
    </div>
  );
}
