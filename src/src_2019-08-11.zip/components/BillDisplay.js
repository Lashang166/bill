import React, { useState, useEffect } from "react";
import moment from "moment";
import "moment/locale/th";

import BillItems from "../components/BillItems";
import BillVendor from "../components/BillVendor";
import BillHeader from "../components/BillHeader";
import BillShippingAddress from "../components/BillShippingAddress";
import PostalCharge from "../components/PostalCharge";
import BillTotal from "../components/BillTotal";
// import BillSteps from "../components/BillSteps";
import BillActions from "../components/BillActions";
import BillPaymentDetail from "../components/BillPaymentDetail";
import StopsOnTopMobile from "../components/StepsOnTopMobile";
import StepComponent from "../components/StepComponent";
import BillStatus from "../components/BillStatus";

import pageConfig from "../config.json";

export default function BillDisplay({ billData, updateBillData, actionType }) {
  if (actionType) {
    console.log("action = " + actionType);
  } else {
    console.log("no ActionType");
  }

  // const [TotalValue, SetTotalValue] = useState(0);
  console.log("BillDisplay:billData", billData);
  // const billData = billData ? billData : null;
  const BillDateStamp = new Date(billData.BillDate);
  const BillDueStamp = new Date(billData.BillDue);
  moment.locale("th");
  const billDataData = billData.Data;
  // console.log("BillDisplay:Data", billDataData);
  const [scrollTopPosition, setScrollTopPosition] = useState(
    window.pageYOffset
  );
  const setScroll = e => {
    const scrollPos = window.scrollY;
    // console.log("setScroll", scrollPos);
    setScrollTopPosition(scrollPos);
  };
  useEffect(() => {
    window.addEventListener("scroll", setScroll);
    return () => {
      window.removeEventListener("scroll", setScroll);
    };
  });

  const [SelectedShipType, setSelectedShipType] = useState(
    billDataData && billDataData.SelectedShipType && billDataData.ShipTypes
      ? billDataData.SelectedShipType
      : billDataData.ShipTypes[0].id
  );

  const [SelectedShipName, setSelectedShipName] = useState(
    billDataData.ShipTypes.filter(ship => ship.id === SelectedShipType)[0]
      .description
  );

  let total = billDataData.items.reduce((totalValue, item) => {
    // console.log(item.Amount, item.PricePerUnit);
    return totalValue + parseFloat(item.Amount) * parseFloat(item.PricePerUnit);
  }, 0);
  let postalCharge = billDataData.ShipTypes.reduce(
    (Value, ShipType) =>
      Value +
      (ShipType.id === SelectedShipType ? parseFloat(ShipType.rate) : 0),
    0
  );
  // console.log(total, postalCharge);
  // SetTotalValue(total + postalCharge);

  if ((billData.BillStatus === "0.0") | (billData.BillStatus === 0.0)) {
    return (
      <div>
        <section className="hero">
          <div className="hero-head border-bottom">
            <div className="container">
              <h1 className="title has-text-grey">{billData.VName}</h1>
              <h2 className="subtitle has-text-grey">
                {pageConfig.billSubtitle}
              </h2>
            </div>
          </div>
        </section>
        <section class="hero">
          <div class="hero-body">
            <div class="container">
              <h1 class="title">ยังไม่พร้อมยังงาน...</h1>
              <h2 class="subtitle" />
            </div>
          </div>
        </section>
      </div>
    );
  }

  if (billData.BillStatus != "0.0") {
    return (
      <div>
        <section className="hero">
          <div className="hero-head border-bottom">
            <div className="container">
              <h1 className="title has-text-grey">{billData.VName}</h1>
              <h2 className="subtitle has-text-grey">
                {pageConfig.billSubtitle}
              </h2>
            </div>
          </div>
          {/* <div
        className="is-hidden-tablet"
        style={{ position: "absolute", top: `${window.pageYOffset}px` }}
      >
        {window.pageYOffset}
      </div> */}

          <div className="hero-body has-background-white-bis my-fix-hero-padding-top">
            <StopsOnTopMobile
              step={billData.BillStatus}
              position={scrollTopPosition}
              link={billData.TrackingNo}
            />
            <div className="container">
              <div className="columns">
                <div className="column is-half">
                  {/* <BillSteps
                step={billData.BillStatus}
                addClass="is-hidden-tablet my-padding"
              /> */}
                  <BillVendor
                    VendorLogo={billData.VLogo}
                    VendorName={billData.AgentName}
                    VendorAddress={billData.VAddr}
                    AgentMobile={billData.AgentMobile}
                    // BillStatusText={billData.BillErrorText}
                  />
                  <BillStatus
                    status={billData.BillStatus}
                    statustext={billData.BillErrorStatus}
                    link={billData.TrackingNo}
                  />
                  <div className="my-padding has-round-border my-margin-top has-background-white">
                    <BillHeader
                      BillNumber={billData.BillNo}
                      BillDate={BillDateStamp}
                      BillDue={BillDueStamp}
                      ShippingAddress={billDataData.ShippingAddress}
                      BillNote={billDataData.note}
                      setBillNote={aaa =>
                        updateBillData({
                          ...billData,
                          Data: { ...billData.Data, note: aaa }
                        })
                      }
                    />
                    <hr />
                    <BillItems
                      items={billData ? billDataData.items : []}
                      setBillItem={itemz =>
                        updateBillData({
                          ...billData,
                          Data: { ...billData.Data, items: itemz }
                        })
                      }
                    />
                    <hr />
                    {billData.BillStatus <= 1 ? (
                      <div>
                        <PostalCharge
                          ShipTypes={billDataData.ShipTypes}
                          SelectedShipType={SelectedShipType}
                          UpdateState={ShipType => {
                            billDataData.SelectedShipType = ShipType;
                            setSelectedShipType(ShipType);
                            setSelectedShipName(
                              billDataData.ShipTypes.filter(
                                ship => ship.id === ShipType
                              )[0].description
                            );
                          }}
                        />
                        <hr />
                      </div>
                    ) : null}
                    <BillTotal
                      TotalValue={total}
                      PostalCharge={postalCharge}
                      PostalName={SelectedShipName}
                      Discount={billData.DiscountValue}
                      DiscountType={billData.DiscountType}
                    />
                  </div>
                </div>
                <div className="column is-half">
                  <StepComponent
                    active={parseInt(billData.BillStatus, 10)}
                    className="content is-hidden-mobile"
                  />
                  {/* <BillSteps
                step={billData.BillStatus}
                addClass="is-hidden-mobile"
              /> */}
                  {billDataData.Payment &&
                  parseInt(billData.BillStatus, 10) > 1 ? (
                    <BillPaymentDetail
                      Payment={billDataData.Payment}
                      BillStatus={billData.BillStatus}
                      setBillStatus={status => {
                        let nextPayment = billDataData.Payment;
                        if (parseInt(status, 10) === 1) {
                          nextPayment = {};
                        }
                        updateBillData({
                          ...billData,
                          BillStatus: status,
                          Data: { ...billDataData, Payment: nextPayment }
                        });
                      }}
                    />
                  ) : null}
                  {billDataData.ShippingAddress &&
                  parseInt(billData.BillStatus, 10) > 2 ? (
                    <BillShippingAddress
                      BillStatus={billData.BillStatus}
                      ShippingAddress={billDataData.ShippingAddress}
                      setBillStatus={status => {
                        updateBillData({
                          ...billData,
                          BillStatus: status
                        });
                      }}
                    />
                  ) : null}
                  {/* <BillSteps step={4} /> */}
                  <BillActions
                    BillNo={billData.BillNo}
                    BankAccounts={billDataData.BankAccounts}
                    ShippingAddress={billDataData.ShippingAddress}
                    Payment={billDataData.Payment}
                    Step={billData.BillStatus}
                    setBillStatus={status => {
                      updateBillData({
                        ...billData,
                        BillStatus: status
                      });
                    }}
                    setPayment={Payment => {
                      updateBillData({
                        ...billData,
                        Data: { ...billData.Data, Payment },
                        BillStatus: "2.0"
                      });
                    }}
                    setShippingAddress={ShippingAddress => {
                      updateBillData({
                        ...billData,
                        Data: { ...billData.Data, ShippingAddress },
                        BillStatus: "3.0"
                      });
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }
}
