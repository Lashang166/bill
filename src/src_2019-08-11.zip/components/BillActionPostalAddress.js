import React, { useState, useEffect } from "react";
import {
  searchAddressByAmphoe,
  searchAddressByDistrict,
  searchAddressByProvince,
  searchAddressByZipcode
} from "thai-address-database";
import SearchBox from "./SearchBox";

export default function BillActionPostalAddress({
  ShippingAddress,
  // setBillStatus,
  updateShippingAddress
}) {
  const [name, setName] = useState(
    ShippingAddress && ShippingAddress.Name ? ShippingAddress.Name : ""
  );
  const [address, setAddress] = useState(
    ShippingAddress && ShippingAddress.Address ? ShippingAddress.Address : ""
  );
  const [tambon, setTambon] = useState(
    ShippingAddress && ShippingAddress.SubDistrict
      ? ShippingAddress.SubDistrict
      : ""
  );
  const [amphur, setAmphur] = useState(
    ShippingAddress && ShippingAddress.District ? ShippingAddress.District : ""
  );
  const [province, setProvince] = useState(
    ShippingAddress && ShippingAddress.Province ? ShippingAddress.Province : ""
  );
  const [postCode, setPostCode] = useState(
    ShippingAddress && ShippingAddress.Postcode ? ShippingAddress.Postcode : ""
  );
  const [mobile, setMobile] = useState(
    ShippingAddress && ShippingAddress.Mobile ? ShippingAddress.Mobile : ""
  );

  useEffect(() => {
    validateInput();
  }, [name, address, tambon, amphur, province, postCode, mobile]);

  const [validated, setValidated] = useState(
    name !== "" &&
      address !== "" &&
      tambon !== "" &&
      amphur !== "" &&
      province !== "" &&
      postCode !== "" &&
      mobile !== ""
  );

  function validateInput() {
    console.log(
      `validateInput before : ${validated}, name : ${name}, mobile: ${mobile}, address: ${address}, tambon: ${tambon}, amphur: ${amphur}, province: ${province}, postCode: ${postCode}`
    );
    setValidated(
      name !== "" &&
        address !== "" &&
        tambon !== "" &&
        amphur !== "" &&
        province !== "" &&
        postCode !== "" &&
        mobile !== ""
    );
    console.log(
      `validateInput after : ${validated}, name : ${name}, mobile: ${mobile}, address: ${address}, tambon: ${tambon}, amphur: ${amphur}, province: ${province}, postCode: ${postCode}`
    );
  }

  // console.log("ShippingData", shippingData);
  // console.log('validated',validated, name, address, tambon, amphur, province, postCode, mobile);
  console.log(
    `validated : ${validated}, name : ${name}, mobile: ${mobile}, address: ${address}, tambon: ${tambon}, amphur: ${amphur}, province: ${province}, postCode: ${postCode}`
  );

  const formatSearchResult = data => {
    return (
      <div
        className="container"
        onClick={e => {
          setTambon(data.district);
          setAmphur(data.amphoe);
          setProvince(data.province);
          setPostCode(data.zipcode);
          setValidated(validated);
        }}
      >
        {data.district}, {data.amphoe}, {data.province} {data.zipcode}
      </div>
    );
  };

  return (
    <div className="my-padding-bottom">
      <div className="card" id="step2">
        <header className="card-header">
          <p className="card-header-title">ข้อมูลที่อยู่จัดส่ง</p>
          <a
            href="#top"
            className="card-header-icon"
            aria-label="more options"
            onClick={e => {
              e.preventDefault();
              setName("");
              setAddress("");
              setMobile("");
              setTambon("");
              setAmphur("");
              setProvince("");
              setPostCode("");
            }}
          >
            <span className="icon my-margin-right">
              <i className="fas fa-minus-circle" aria-hidden="true" />
            </span>
            ล้างข้อมูล
          </a>
        </header>
        <div className="card-content">
          <div className="content">
            <div className="field">
              <label className="label">ชื่อ-นามสกุล</label>
              <div className="control">
                <input
                  className={`input ${name.trim() === "" ? "is-danger" : ""}`}
                  type="text"
                  value={name}
                  onChange={e => {
                    setName(e.target.value);
                  }}
                  placeholder="ชื่อ-นามสกุลผู้รับ"
                />
              </div>
            </div>
            <div className="field">
              <label className="label">เบอร์มือถือ</label>
              <div className="control">
                <input
                  className={`input ${mobile.trim() === "" ? "is-danger" : ""}`}
                  value={mobile}
                  onChange={e => {
                    setMobile(e.target.value);
                  }}
                  type="tel"
                  placeholder="เบอร์ที่สะดวกติดต่อรับสินค้า"
                />
              </div>
            </div>
            <div className="field">
              <label className="label">ที่อยู่</label>
              <div className="control">
                <input
                  className={`input ${
                    address.trim() === "" ? "is-danger" : ""
                  }`}
                  type="text"
                  value={address}
                  onChange={e => {
                    setAddress(e.target.value);
                  }}
                  placeholder="เลขที่ ซอย ถนน"
                />
              </div>
            </div>
            {tambon.length > 0 ? (
              <SearchBox
                label="ตำบล"
                name="tambon"
                className={tambon.trim() === "" ? "is-danger" : ""}
                value={tambon}
                placeholder="ค้นหาจากชื่อ ตำบล"
                onInputChange={e => {
                  setTambon(e.target.value);
                }}
                searchFunction={searchAddressByDistrict}
                FormatResult={formatSearchResult}
              />
            ) : null}

            {amphur.length > 0 ? (
              <SearchBox
                label="อำเภอ"
                className={amphur.trim() === "" ? "is-danger" : ""}
                name="amphur"
                value={amphur}
                placeholder="ค้นหาจากชื่อ อำเภอ"
                onInputChange={e => {
                  setAmphur(e.target.value);
                }}
                searchFunction={searchAddressByAmphoe}
                FormatResult={formatSearchResult}
              />
            ) : null}

            {province.length > 0 ? (
              <SearchBox
                label="จังหวัด"
                className={province.trim() === "" ? "is-danger" : ""}
                name="province"
                value={province}
                placeholder="ค้นหาจากชื่อ จังหวัด"
                onInputChange={e => {
                  setProvince(e.target.value);
                }}
                searchFunction={searchAddressByProvince}
                FormatResult={formatSearchResult}
              />
            ) : null}

            <SearchBox
              label="รหัสไปรษณีย์"
              name="postcode"
              className={postCode.trim() === "" ? "is-danger" : ""}
              value={postCode}
              type="tel"
              placeholder="ค้นหาจากรหัสไปรษณีย์"
              onInputChange={e => {
                setPostCode(e.target.value);
              }}
              searchFunction={searchAddressByZipcode}
              FormatResult={formatSearchResult}
            />
          </div>
        </div>
        {validated ? (
          <footer className="card-footer">
            <a
              href="#t"
              className="card-footer-item"
              onClick={e => {
                e.preventDefault();
                updateShippingAddress({
                  Name: name,
                  Address: address,
                  SubDistrict: tambon,
                  District: amphur,
                  Province: province,
                  Postcode: postCode,
                  Mobile: mobile
                });
              }}
            >
              ยืนยัน
            </a>
          </footer>
        ) : null}
      </div>
    </div>
  );
}
